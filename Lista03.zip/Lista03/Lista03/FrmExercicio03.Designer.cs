﻿namespace Lista03
{
    partial class FrmExercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPeso = new System.Windows.Forms.Label();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblResul = new System.Windows.Forms.Label();
            this.Pnl02 = new System.Windows.Forms.Panel();
            this.Pnl01 = new System.Windows.Forms.Panel();
            this.Pnl02.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.BackColor = System.Drawing.Color.Red;
            this.lblPeso.Font = new System.Drawing.Font("Arial Narrow", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeso.Location = new System.Drawing.Point(32, 74);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(318, 37);
            this.lblPeso.TabIndex = 0;
            this.lblPeso.Text = "Peso da Refeição em Kg:";
            // 
            // txtPeso
            // 
            this.txtPeso.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPeso.Location = new System.Drawing.Point(113, 144);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(161, 38);
            this.txtPeso.TabIndex = 1;
            // 
            // btnCalc
            // 
            this.btnCalc.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(323, 216);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(136, 75);
            this.btnCalc.TabIndex = 2;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lblResul
            // 
            this.lblResul.AutoSize = true;
            this.lblResul.Font = new System.Drawing.Font("Arial Narrow", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResul.Location = new System.Drawing.Point(374, 365);
            this.lblResul.Name = "lblResul";
            this.lblResul.Size = new System.Drawing.Size(0, 31);
            this.lblResul.TabIndex = 3;
            // 
            // Pnl02
            // 
            this.Pnl02.BackColor = System.Drawing.Color.Red;
            this.Pnl02.Controls.Add(this.lblPeso);
            this.Pnl02.Location = new System.Drawing.Point(-3, -2);
            this.Pnl02.Name = "Pnl02";
            this.Pnl02.Size = new System.Drawing.Size(800, 203);
            this.Pnl02.TabIndex = 5;
            // 
            // Pnl01
            // 
            this.Pnl01.BackColor = System.Drawing.Color.Black;
            this.Pnl01.Location = new System.Drawing.Point(-3, 134);
            this.Pnl01.Name = "Pnl01";
            this.Pnl01.Size = new System.Drawing.Size(800, 322);
            this.Pnl01.TabIndex = 4;
            // 
            // FrmExercicio03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResul);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.Pnl02);
            this.Controls.Add(this.Pnl01);
            this.Name = "FrmExercicio03";
            this.Text = "FrmExercicio03";
            this.Pnl02.ResumeLayout(false);
            this.Pnl02.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblResul;
        private System.Windows.Forms.Panel Pnl02;
        private System.Windows.Forms.Panel Pnl01;
    }
}