﻿namespace Lista03
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum1 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.lblNum3 = new System.Windows.Forms.Label();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnPorc = new System.Windows.Forms.Button();
            this.lblExercicio = new System.Windows.Forms.Label();
            this.lblResulSoma = new System.Windows.Forms.Label();
            this.lblResulPorc = new System.Windows.Forms.Label();
            this.lblResulMedia = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Location = new System.Drawing.Point(73, 103);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(99, 25);
            this.lblNum1.TabIndex = 0;
            this.lblNum1.Text = "Numero 01";
            this.lblNum1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(78, 148);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(129, 32);
            this.txtNum1.TabIndex = 1;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(267, 148);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(129, 32);
            this.txtNum2.TabIndex = 3;
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Location = new System.Drawing.Point(262, 103);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(99, 25);
            this.lblNum2.TabIndex = 2;
            this.lblNum2.Text = "Numero 02";
            // 
            // txtNum3
            // 
            this.txtNum3.Location = new System.Drawing.Point(454, 148);
            this.txtNum3.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(129, 32);
            this.txtNum3.TabIndex = 5;
            // 
            // lblNum3
            // 
            this.lblNum3.AutoSize = true;
            this.lblNum3.Location = new System.Drawing.Point(449, 103);
            this.lblNum3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNum3.Name = "lblNum3";
            this.lblNum3.Size = new System.Drawing.Size(99, 25);
            this.lblNum3.TabIndex = 4;
            this.lblNum3.Text = "Numero 03";
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(78, 266);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(129, 50);
            this.btnSoma.TabIndex = 6;
            this.btnSoma.Text = "Soma";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(267, 266);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(129, 50);
            this.btnMedia.TabIndex = 7;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnPorc
            // 
            this.btnPorc.Location = new System.Drawing.Point(454, 266);
            this.btnPorc.Name = "btnPorc";
            this.btnPorc.Size = new System.Drawing.Size(129, 50);
            this.btnPorc.TabIndex = 8;
            this.btnPorc.Text = "Porcentagem";
            this.btnPorc.UseVisualStyleBackColor = true;
            this.btnPorc.Click += new System.EventHandler(this.btnPorc_Click);
            // 
            // lblExercicio
            // 
            this.lblExercicio.AutoSize = true;
            this.lblExercicio.Font = new System.Drawing.Font("Arial Narrow", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio.Location = new System.Drawing.Point(32, 34);
            this.lblExercicio.Name = "lblExercicio";
            this.lblExercicio.Size = new System.Drawing.Size(175, 42);
            this.lblExercicio.TabIndex = 9;
            this.lblExercicio.Text = "Exercício 01";
            // 
            // lblResulSoma
            // 
            this.lblResulSoma.AutoSize = true;
            this.lblResulSoma.Location = new System.Drawing.Point(73, 382);
            this.lblResulSoma.Name = "lblResulSoma";
            this.lblResulSoma.Size = new System.Drawing.Size(142, 25);
            this.lblResulSoma.TabIndex = 10;
            this.lblResulSoma.Text = "Resultado Soma";
            // 
            // lblResulPorc
            // 
            this.lblResulPorc.AutoSize = true;
            this.lblResulPorc.Location = new System.Drawing.Point(449, 382);
            this.lblResulPorc.Name = "lblResulPorc";
            this.lblResulPorc.Size = new System.Drawing.Size(202, 25);
            this.lblResulPorc.TabIndex = 11;
            this.lblResulPorc.Text = "Resultado Porcentagem";
            // 
            // lblResulMedia
            // 
            this.lblResulMedia.AutoSize = true;
            this.lblResulMedia.Location = new System.Drawing.Point(262, 382);
            this.lblResulMedia.Name = "lblResulMedia";
            this.lblResulMedia.Size = new System.Drawing.Size(146, 25);
            this.lblResulMedia.TabIndex = 12;
            this.lblResulMedia.Text = "Resultado Média";
            this.lblResulMedia.Click += new System.EventHandler(this.label4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(843, 452);
            this.Controls.Add(this.lblResulMedia);
            this.Controls.Add(this.lblResulPorc);
            this.Controls.Add(this.lblResulSoma);
            this.Controls.Add(this.lblExercicio);
            this.Controls.Add(this.btnPorc);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.lblNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.lblNum1);
            this.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 6, 5, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum1;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.Label lblNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Label lblNum3;
        private System.Windows.Forms.Button btnSoma;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnPorc;
        private System.Windows.Forms.Label lblExercicio;
        private System.Windows.Forms.Label lblResulSoma;
        private System.Windows.Forms.Label lblResulPorc;
        private System.Windows.Forms.Label lblResulMedia;
    }
}

