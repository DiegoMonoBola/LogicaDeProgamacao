﻿namespace Lista03
{
    partial class FrmExercicio04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtLados = new System.Windows.Forms.TextBox();
            this.lblResul = new System.Windows.Forms.Label();
            this.btnCalc = new System.Windows.Forms.Button();
            this.Pnl02 = new System.Windows.Forms.Panel();
            this.Pnl01 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lblLados = new System.Windows.Forms.Label();
            this.Pnl01.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtLados
            // 
            this.txtLados.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLados.Location = new System.Drawing.Point(101, 146);
            this.txtLados.Name = "txtLados";
            this.txtLados.Size = new System.Drawing.Size(166, 38);
            this.txtLados.TabIndex = 10;
            // 
            // lblResul
            // 
            this.lblResul.AutoSize = true;
            this.lblResul.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResul.Location = new System.Drawing.Point(347, 339);
            this.lblResul.Name = "lblResul";
            this.lblResul.Size = new System.Drawing.Size(0, 31);
            this.lblResul.TabIndex = 11;
            // 
            // btnCalc
            // 
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(101, 290);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(144, 80);
            this.btnCalc.TabIndex = 12;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // Pnl02
            // 
            this.Pnl02.BackColor = System.Drawing.Color.SteelBlue;
            this.Pnl02.Location = new System.Drawing.Point(-7, 88);
            this.Pnl02.Name = "Pnl02";
            this.Pnl02.Size = new System.Drawing.Size(814, 275);
            this.Pnl02.TabIndex = 14;
            // 
            // Pnl01
            // 
            this.Pnl01.BackColor = System.Drawing.Color.DarkOrchid;
            this.Pnl01.Controls.Add(this.flowLayoutPanel1);
            this.Pnl01.Location = new System.Drawing.Point(-4, 1);
            this.Pnl01.Name = "Pnl01";
            this.Pnl01.Size = new System.Drawing.Size(811, 452);
            this.Pnl01.TabIndex = 15;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(655, 34);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // lblLados
            // 
            this.lblLados.AutoSize = true;
            this.lblLados.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLados.Location = new System.Drawing.Point(95, 63);
            this.lblLados.Name = "lblLados";
            this.lblLados.Size = new System.Drawing.Size(300, 31);
            this.lblLados.TabIndex = 9;
            this.lblLados.Text = "Insira o valor dos lados:";
            // 
            // FrmExercicio04
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.lblResul);
            this.Controls.Add(this.txtLados);
            this.Controls.Add(this.lblLados);
            this.Controls.Add(this.Pnl02);
            this.Controls.Add(this.Pnl01);
            this.Name = "FrmExercicio04";
            this.Text = "FrmExercicio05";
            this.Pnl01.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtLados;
        private System.Windows.Forms.Label lblResul;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Panel Pnl02;
        private System.Windows.Forms.Panel Pnl01;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lblLados;
    }
}