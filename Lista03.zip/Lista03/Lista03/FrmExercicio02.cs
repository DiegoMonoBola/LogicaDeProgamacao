﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio02 : Form
    {
        public FrmExercicio02()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            float pagar = float.Parse(txtPreço.Text);
            float litro = float.Parse(txtLitro.Text);
            float resultado = (pagar / litro);
            lblresultado.Text = resultado.ToString() + " Litros de Gasolina";
        }
    }
}
