﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio07 : Form
    {
        public FrmExercicio07()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            float pequeno = float.Parse(txtPequeno.Text);
            float medio = float.Parse(txtMedio.Text);
            float grande = float.Parse(txtGrande.Text);
            float pequenoResul = pequeno * 12;
            float medioResul = medio * 16;
            float grandeResul = grande * 22;
            float resul = pequenoResul + medioResul + grandeResul;
            lblResul.Text = resul.ToString()+"R$";
        }
    }
}
