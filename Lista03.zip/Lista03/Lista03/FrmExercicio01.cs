﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum3.Text);
            float resultado = num1 + num3;
            lblResulSoma.Text="Soma igual a: "+resultado.ToString();
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media = (num1 + num2 + num3) / 3;
            lblResulMedia.Text = "Média dos três igual a: " + media;
        }

        private void btnPorc_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float total = (num1 + num2 + num3);
            float porcentagem1, porcentagem2, porcentagem3;
            porcentagem1 = (num1 / total)*100;
            porcentagem2 = (num2 / total)*100;
            porcentagem3 = (num3 / total)*100;
            lblResulPorc.Text = "Porcentagem Num1: " + porcentagem1 + "% - " +"Porcentagem Num2: " + porcentagem2+ "% - " + "Porcentagem Num3: " +porcentagem3 + "% ";
        }
    }
}
