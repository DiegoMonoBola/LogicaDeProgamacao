﻿namespace Lista03
{
    partial class FrmExercicio07
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGrande = new System.Windows.Forms.Label();
            this.lblMedio = new System.Windows.Forms.Label();
            this.lblPequeno = new System.Windows.Forms.Label();
            this.txtPequeno = new System.Windows.Forms.TextBox();
            this.txtMedio = new System.Windows.Forms.TextBox();
            this.txtGrande = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblResul = new System.Windows.Forms.Label();
            this.Pnl02 = new System.Windows.Forms.Panel();
            this.pnl03 = new System.Windows.Forms.Panel();
            this.Pnl01 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.Pnl01.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblGrande
            // 
            this.lblGrande.AutoSize = true;
            this.lblGrande.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrande.Location = new System.Drawing.Point(518, 84);
            this.lblGrande.Name = "lblGrande";
            this.lblGrande.Size = new System.Drawing.Size(227, 31);
            this.lblGrande.TabIndex = 10;
            this.lblGrande.Text = "Tamanho grande:";
            // 
            // lblMedio
            // 
            this.lblMedio.AutoSize = true;
            this.lblMedio.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedio.Location = new System.Drawing.Point(279, 84);
            this.lblMedio.Name = "lblMedio";
            this.lblMedio.Size = new System.Drawing.Size(216, 31);
            this.lblMedio.TabIndex = 11;
            this.lblMedio.Text = "Tamanho médio:";
            this.lblMedio.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblPequeno
            // 
            this.lblPequeno.AutoSize = true;
            this.lblPequeno.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPequeno.Location = new System.Drawing.Point(12, 84);
            this.lblPequeno.Name = "lblPequeno";
            this.lblPequeno.Size = new System.Drawing.Size(248, 31);
            this.lblPequeno.TabIndex = 12;
            this.lblPequeno.Text = "Tamanho pequeno:";
            // 
            // txtPequeno
            // 
            this.txtPequeno.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPequeno.Location = new System.Drawing.Point(18, 144);
            this.txtPequeno.Name = "txtPequeno";
            this.txtPequeno.Size = new System.Drawing.Size(166, 38);
            this.txtPequeno.TabIndex = 13;
            // 
            // txtMedio
            // 
            this.txtMedio.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMedio.Location = new System.Drawing.Point(285, 144);
            this.txtMedio.Name = "txtMedio";
            this.txtMedio.Size = new System.Drawing.Size(166, 38);
            this.txtMedio.TabIndex = 14;
            // 
            // txtGrande
            // 
            this.txtGrande.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGrande.Location = new System.Drawing.Point(524, 144);
            this.txtGrande.Name = "txtGrande";
            this.txtGrande.Size = new System.Drawing.Size(166, 38);
            this.txtGrande.TabIndex = 15;
            // 
            // btnCalc
            // 
            this.btnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(322, 275);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(144, 80);
            this.btnCalc.TabIndex = 16;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lblResul
            // 
            this.lblResul.AutoSize = true;
            this.lblResul.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResul.Location = new System.Drawing.Point(359, 386);
            this.lblResul.Name = "lblResul";
            this.lblResul.Size = new System.Drawing.Size(0, 31);
            this.lblResul.TabIndex = 17;
            // 
            // Pnl02
            // 
            this.Pnl02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Pnl02.Location = new System.Drawing.Point(-5, -10);
            this.Pnl02.Name = "Pnl02";
            this.Pnl02.Size = new System.Drawing.Size(405, 278);
            this.Pnl02.TabIndex = 18;
            // 
            // pnl03
            // 
            this.pnl03.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnl03.Location = new System.Drawing.Point(393, 0);
            this.pnl03.Name = "pnl03";
            this.pnl03.Size = new System.Drawing.Size(418, 268);
            this.pnl03.TabIndex = 19;
            // 
            // Pnl01
            // 
            this.Pnl01.BackColor = System.Drawing.Color.Indigo;
            this.Pnl01.Controls.Add(this.btnCalc);
            this.Pnl01.Controls.Add(this.flowLayoutPanel1);
            this.Pnl01.Location = new System.Drawing.Point(-5, -1);
            this.Pnl01.Name = "Pnl01";
            this.Pnl01.Size = new System.Drawing.Size(811, 452);
            this.Pnl01.TabIndex = 20;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(655, 34);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // FrmExercicio07
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResul);
            this.Controls.Add(this.txtGrande);
            this.Controls.Add(this.txtMedio);
            this.Controls.Add(this.txtPequeno);
            this.Controls.Add(this.lblPequeno);
            this.Controls.Add(this.lblMedio);
            this.Controls.Add(this.lblGrande);
            this.Controls.Add(this.pnl03);
            this.Controls.Add(this.Pnl02);
            this.Controls.Add(this.Pnl01);
            this.Name = "FrmExercicio07";
            this.Text = "FrmExercicio07";
            this.Pnl01.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGrande;
        private System.Windows.Forms.Label lblMedio;
        private System.Windows.Forms.Label lblPequeno;
        private System.Windows.Forms.TextBox txtPequeno;
        private System.Windows.Forms.TextBox txtMedio;
        private System.Windows.Forms.TextBox txtGrande;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblResul;
        private System.Windows.Forms.Panel Pnl02;
        private System.Windows.Forms.Panel pnl03;
        private System.Windows.Forms.Panel Pnl01;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
    }
}